

<?php $__env->startSection('title', 'Data Unit - Laporan'); ?>

<?php $__env->startSection('content'); ?>
<!-- Header -->
<div class="row mb-4">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <h5 class="mb-1">
                    <i class="fas fa-building me-2"></i>Data Unit
                </h5>
                <p class="text-muted mb-0">Status optimasi dan data pegawai per unit</p>
            </div>
        </div>
    </div>
</div>

<!-- Sub Menu Navigation -->
<div class="row mb-3">
    <div class="col-12">
        <div class="btn-group" role="group">
            <a href="<?php echo e(route('admin.laporan.pegawai')); ?>" class="btn btn-outline-primary">
                <i class="fas fa-users me-1"></i>Data Pegawai
            </a>
            <a href="<?php echo e(route('admin.laporan.unit')); ?>" class="btn btn-primary">
                <i class="fas fa-building me-1"></i>Data Unit
            </a>
        </div>
    </div>
</div>

<!-- Filter Status Unit -->
<div class="row mb-4">
    <div class="col-12">
        <div class="card border-0 shadow-sm">
            <div class="card-body">
                <form method="GET" action="<?php echo e(route('admin.laporan.unit')); ?>" class="row g-3 align-items-end">
                    <div class="col-md-6">
                        <label for="unit_status" class="form-label">
                            <i class="fas fa-filter me-2"></i><strong>Filter Berdasarkan Status Unit</strong>
                        </label>
                        <select class="form-select" id="unit_status" name="unit_status">
                            <option value="">Semua Status</option>
                            <option value="optimal" <?php echo e($selectedUnitStatus == 'optimal' ? 'selected' : ''); ?>>
                                🟢 Optimal (Semua Pegawai Optimal)
                            </option>
                            <option value="underload" <?php echo e($selectedUnitStatus == 'underload' ? 'selected' : ''); ?>>
                                🟡 Kekurangan Beban Kerja (Ada yang Kurang)
                            </option>
                            <option value="overload" <?php echo e($selectedUnitStatus == 'overload' ? 'selected' : ''); ?>>
                                🔴 Kelebihan Beban Kerja (Ada yang Lebih)
                            </option>
                            <option value="mixed" <?php echo e($selectedUnitStatus == 'mixed' ? 'selected' : ''); ?>>
                                🟠 Kekurangan dan Kelebihan (Campuran)
                            </option>
                        </select>
                    </div>
                    
                    <div class="col-md-3">
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="fas fa-search me-1"></i>Terapkan Filter
                        </button>
                    </div>
                    
                    <div class="col-md-3">
                        <a href="<?php echo e(route('admin.laporan.unit')); ?>" class="btn btn-secondary w-100">
                            <i class="fas fa-times me-1"></i>Reset Filter
                        </a>
                    </div>
                </form>
                
                <?php if($selectedUnitStatus): ?>
                    <div class="mt-3">
                        <span class="badge bg-info">
                            <i class="fas fa-info-circle me-1"></i>
                            Menampilkan unit dengan status: 
                            <?php if($selectedUnitStatus === 'optimal'): ?>
                                Optimal
                            <?php elseif($selectedUnitStatus === 'underload'): ?>
                                Kekurangan Beban Kerja
                            <?php elseif($selectedUnitStatus === 'overload'): ?>
                                Kelebihan Beban Kerja
                            <?php else: ?>
                                Kekurangan dan Kelebihan Beban Kerja
                            <?php endif; ?>
                        </span>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Unit Status Cards -->
<div class="row mb-4">
    <?php $__currentLoopData = $unitOptimization; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unitName => $stats): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-6 col-lg-4 mb-3">
            <div class="card h-100 border-0 shadow-sm">
                <div class="card-body">
                    <h6 class="card-title fw-bold mb-3">
                        <i class="fas fa-building me-2"></i><?php echo e($unitName); ?>

                    </h6>
                    
                    <!-- Progress Bar -->
                    <div class="progress mb-3" style="height: 25px;">
                        <div class="progress-bar 
                            <?php if($stats['status'] === 'optimal'): ?> bg-success
                            <?php elseif($stats['status'] === 'overload'): ?> bg-danger
                            <?php elseif($stats['status'] === 'mixed'): ?> bg-info
                            <?php else: ?> bg-warning
                            <?php endif; ?>" 
                            role="progressbar" 
                            style="width: <?php echo e($stats['optimal_percentage']); ?>%">
                            <?php echo e($stats['optimal_percentage']); ?>%
                        </div>
                    </div>
                    
                    <!-- Statistics -->
                    <div class="row text-center mb-3">
                        <div class="col-3">
                            <div class="fw-bold text-primary"><?php echo e($stats['total']); ?></div>
                            <small class="text-muted">Total</small>
                        </div>
                        <div class="col-3">
                            <div class="fw-bold text-success"><?php echo e($stats['optimal']); ?></div>
                            <small class="text-muted">Optimal</small>
                        </div>
                        <div class="col-3">
                            <div class="fw-bold text-warning"><?php echo e($stats['underload']); ?></div>
                            <small class="text-muted">Kurang</small>
                        </div>
                        <div class="col-3">
                            <div class="fw-bold text-danger"><?php echo e($stats['overload']); ?></div>
                            <small class="text-muted">Lebih</small>
                        </div>
                    </div>
                    
                    <!-- Status Badge -->
                    <div class="mb-3">
                        <span class="badge 
                            <?php if($stats['status'] === 'optimal'): ?> bg-success
                            <?php elseif($stats['status'] === 'overload'): ?> bg-danger
                            <?php elseif($stats['status'] === 'mixed'): ?> bg-info
                            <?php else: ?> bg-warning
                            <?php endif; ?>">
                            <?php echo e($stats['status_label']); ?>

                        </span>
                    </div>
                    
                    <!-- Action Buttons -->
                    <div class="btn-group w-100" role="group">
                        <a href="<?php echo e(route('admin.laporan.unit.pegawai', ['unit' => urlencode($unitName)])); ?>" 
                           class="btn btn-sm btn-outline-primary">
                            <i class="fas fa-users me-1"></i>Lihat Pegawai
                        </a>
                        <a href="<?php echo e(route('admin.laporan.unit.pdf', $unitName)); ?>" 
                           class="btn btn-sm btn-primary">
                            <i class="fas fa-file-pdf me-1"></i>PDF
                        </a>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<!-- Info Box -->
<div class="row">
    <div class="col-12">
        <div class="card bg-light">
            <div class="card-body">
                <h6 class="mb-3">
                    <i class="fas fa-info-circle me-2"></i>Petunjuk
                </h6>
                <ul class="mb-0">
                    <li>Klik <strong>"Lihat Pegawai"</strong> pada kartu unit untuk membuka halaman data pegawai unit tersebut</li>
                    <li>Gunakan <strong>"PDF"</strong> untuk download laporan lengkap unit</li>
                    <li>Progress bar menunjukkan persentase pegawai optimal dalam unit</li>
                    <li>Status unit: 
                        <span class="badge bg-success">🟢 Optimal</span> (semua optimal), 
                        <span class="badge bg-warning">🟡 Kekurangan</span> (ada yang kurang), 
                        <span class="badge bg-danger">🔴 Kelebihan</span> (ada yang lebih),
                        <span class="badge bg-info">🟠 Campuran</span> (ada kurang & lebih)
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Laragon\laragon\www\WOLA\resources\views/admin/reports/units.blade.php ENDPATH**/ ?>