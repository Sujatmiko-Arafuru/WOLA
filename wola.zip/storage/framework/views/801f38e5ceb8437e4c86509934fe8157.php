

<?php $__env->startSection('title', 'Notifikasi Perubahan'); ?>

<?php $__env->startSection('content'); ?>
<!-- Header -->
<div class="row mb-4">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="mb-1">
                            <i class="fas fa-bell me-2"></i>Notifikasi Perubahan
                        </h5>
                        <p class="text-muted mb-0">Pantau perubahan yang dilakukan pegawai pada entri beban kerja</p>
                    </div>
                    <?php if($editLogs->count() > 0): ?>
                        <form method="POST" action="<?php echo e(route('admin.mark-all-notifications-read')); ?>" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <button type="submit" class="btn btn-success">
                                <i class="fas fa-check-double me-2"></i>Tandai Semua Dibaca
                            </button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Notifications -->
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <?php if($editLogs->count() > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Pegawai</th>
                                    <th>Tugas</th>
                                    <th>Alasan Pengeditan</th>
                                    <th>Perubahan</th>
                                    <th>Edit Ke-</th>
                                    <th>Status</th>
                                    <th>Tanggal</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $editLogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($log->user && $log->workloadEntry && $log->workloadEntry->task): ?>
                                    <tr class="<?php echo e(!$log->admin_notified ? 'table-warning' : ''); ?>">
                                        <td><?php echo e($editLogs->firstItem() + $index); ?></td>
                                        <td><?php echo e($log->user->name); ?></td>
                                        <td><?php echo e($log->workloadEntry->task->task_description); ?></td>
                                        <td>
                                            <div class="alert alert-primary mb-0 p-2" style="font-size: 0.9em;">
                                                <i class="fas fa-comment me-1"></i>
                                                <strong><?php echo e($log->reason ?: 'Tidak ada alasan yang diberikan'); ?></strong>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="small">
                                                <strong>Sebelum:</strong> <?php echo e($log->old_quantity); ?> 
                                                <?php switch($log->old_time_unit):
                                                    case ('daily'): ?> Harian <?php break; ?>
                                                    <?php case ('weekly'): ?> Mingguan <?php break; ?>
                                                    <?php case ('monthly'): ?> Bulanan <?php break; ?>
                                                    <?php case ('yearly'): ?> Tahunan <?php break; ?>
                                                <?php endswitch; ?><br>
                                                <strong>Sesudah:</strong> <?php echo e($log->new_quantity); ?> 
                                                <?php switch($log->new_time_unit):
                                                    case ('daily'): ?> Harian <?php break; ?>
                                                    <?php case ('weekly'): ?> Mingguan <?php break; ?>
                                                    <?php case ('monthly'): ?> Bulanan <?php break; ?>
                                                    <?php case ('yearly'): ?> Tahunan <?php break; ?>
                                                <?php endswitch; ?><br>
                                                <strong>Total Menit:</strong> <?php echo e(number_format($log->old_total_minutes)); ?> → <?php echo e(number_format($log->new_total_minutes)); ?>

                                            </div>
                                        </td>
                                        <td>
                                            <span class="badge" style="background: linear-gradient(135deg, #f1c40f, #f39c12);">Edit ke-<?php echo e($log->edit_number); ?></span>
                                        </td>
                                        <td>
                                            <?php if($log->admin_notified): ?>
                                                <span class="badge" style="background: linear-gradient(135deg, #27ae60, #2ecc71);">Sudah Dibaca</span>
                                            <?php else: ?>
                                                <span class="badge" style="background: linear-gradient(135deg, #e74c3c, #c0392b);">Belum Dibaca</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($log->created_at->format('d/m/Y H:i')); ?></td>
                                        <td>
                                            <div class="btn-group" role="group">
                                                <a href="<?php echo e(route('admin.detail-perubahan', $log)); ?>" 
                                                   class="btn btn-sm btn-info">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                                <?php if(!$log->admin_notified): ?>
                                                    <form method="POST" 
                                                          action="<?php echo e(route('admin.mark-notification-read', $log)); ?>" 
                                                          class="d-inline">
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('PATCH'); ?>
                                                        <button type="submit" class="btn btn-sm btn-success">
                                                            <i class="fas fa-check"></i>
                                                        </button>
                                                    </form>
                                                <?php endif; ?>
                                                <form method="POST" 
                                                      action="<?php echo e(route('admin.notifikasi-perubahan', $log)); ?>" 
                                                      class="d-inline btn-delete">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-sm btn-danger">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <!-- Pagination -->
                    <div class="d-flex justify-content-between align-items-center mt-4">
                        <div class="text-muted">
                            Menampilkan <?php echo e($editLogs->firstItem() ?? 0); ?> - <?php echo e($editLogs->lastItem() ?? 0); ?> dari <?php echo e($editLogs->total()); ?> notifikasi
                        </div>
                        <div>
                            <?php echo e($editLogs->links('pagination::bootstrap-5')); ?>

                        </div>
                    </div>
                <?php else: ?>
                    <div class="text-center py-5">
                        <i class="fas fa-bell-slash fa-4x text-muted mb-3"></i>
                        <h5 class="text-muted">Belum ada notifikasi</h5>
                        <p class="text-muted">Tidak ada perubahan yang perlu diperhatikan saat ini.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Laragon\laragon\www\WOLA\resources\views/admin/notifikasi-perubahan.blade.php ENDPATH**/ ?>