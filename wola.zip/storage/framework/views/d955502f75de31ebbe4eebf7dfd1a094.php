<?php $__env->startSection('title', 'Kelola Akun'); ?>

<?php $__env->startSection('content'); ?>
<!-- Header -->
<div class="row mb-4">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="mb-1">
                            <i class="fas fa-users me-2"></i>Kelola Akun Pegawai
                        </h5>
                        <p class="text-muted mb-0">Kelola data akun pegawai dalam sistem</p>
                    </div>
                    <a href="<?php echo e(route('admin.tambah-akun')); ?>" class="btn btn-primary">
                        <i class="fas fa-plus me-2"></i>Tambah Pegawai
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Search Bar -->
<div class="row mb-4">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <form method="GET" action="<?php echo e(route('admin.kelola-akun')); ?>">
                    <div class="row g-3 align-items-end">
                        <div class="col-md-10">
                            <label for="search" class="form-label">
                                <i class="fas fa-search me-2"></i>Cari Pegawai
                            </label>
                            <input type="text" 
                                   class="form-control" 
                                   id="search" 
                                   name="search" 
                                   placeholder="Cari berdasarkan Nama atau NIP..."
                                   value="<?php echo e($search ?? ''); ?>">
                            <small class="text-muted">Ketik nama atau NIP pegawai yang ingin dicari</small>
                        </div>
                        <div class="col-md-2">
                            <button type="submit" class="btn btn-primary w-100">
                                <i class="fas fa-search me-2"></i>Cari
                            </button>
                            <?php if($search): ?>
                                <a href="<?php echo e(route('admin.kelola-akun')); ?>" class="btn btn-secondary w-100 mt-2">
                                    <i class="fas fa-times me-2"></i>Reset
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Users Table -->
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <?php if($search): ?>
                    <div class="alert alert-info mb-3">
                        <i class="fas fa-info-circle me-2"></i>
                        Hasil pencarian untuk: <strong>"<?php echo e($search); ?>"</strong> 
                        - Ditemukan <strong><?php echo e($users->total()); ?></strong> pegawai
                    </div>
                <?php endif; ?>
                
                <?php if($users->count() > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Nama</th>
                                    <th>NIP</th>
                                    <th>Email</th>
                                    <th>Unit</th>
                                    <th>Menit per hari</th>
                                    <th>Status</th>
                                    <th>Tanggal Dibuat</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($users->firstItem() + $index); ?></td>
                                        <td><?php echo e($user->name); ?></td>
                                        <td>
                                            <span class="badge" style="background: linear-gradient(135deg, #17a2b8, #138496);"><?php echo e($user->nip); ?></span>
                                        </td>
                                        <td><?php echo e($user->email); ?></td>
                                        <td>
                                            <span class="badge bg-primary"><?php echo e($user->unit ?? '-'); ?></span>
                                        </td>
                                        <td>
                                            <?php
                                                $totalMinutesPerDay = $user->workloadEntries->sum(function($entry) {
                                                    return $entry->calculateMinutesPerDay();
                                                });
                                            ?>
                                            <span class="badge" style="background: linear-gradient(135deg, #17a2b8, #138496);"><?php echo e(number_format($totalMinutesPerDay, 1)); ?> menit</span>
                                        </td>
                                        <td>
                                            <?php
                                                $effectiveWorkTime = 300; // 5 jam = 300 menit
                                                if ($totalMinutesPerDay >= $effectiveWorkTime - 10 && $totalMinutesPerDay <= $effectiveWorkTime + 10) {
                                                    $status = 'optimal';
                                                    $statusLabel = 'Optimal';
                                                    $statusColor = 'linear-gradient(135deg, #27ae60, #2ecc71)';
                                                } elseif ($totalMinutesPerDay > $effectiveWorkTime + 10) {
                                                    $status = 'overload';
                                                    $statusLabel = 'Berlebih';
                                                    $statusColor = 'linear-gradient(135deg, #e74c3c, #c0392b)';
                                                } else {
                                                    $status = 'underload';
                                                    $statusLabel = 'Kurang';
                                                    $statusColor = 'linear-gradient(135deg, #f1c40f, #f39c12)';
                                                }
                                            ?>
                                            <span class="badge" style="background: <?php echo e($statusColor); ?>;"><?php echo e($statusLabel); ?></span>
                                        </td>
                                        <td><?php echo e($user->created_at->format('d/m/Y')); ?></td>
                                        <td>
                                            <div class="btn-group" role="group">
                                                <a href="<?php echo e(route('admin.detail-akun', $user)); ?>" 
                                                   class="btn btn-sm btn-info">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                                <a href="<?php echo e(route('admin.edit-akun', $user)); ?>" 
                                                   class="btn btn-sm btn-warning">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                                <form method="POST" 
                                                      action="<?php echo e(route('admin.kelola-akun', $user)); ?>" 
                                                      class="d-inline btn-delete">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-sm btn-danger">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <!-- Pagination -->
                    <div class="d-flex justify-content-between align-items-center mt-4">
                        <div class="text-muted">
                            Menampilkan <?php echo e($users->firstItem() ?? 0); ?> - <?php echo e($users->lastItem() ?? 0); ?> dari <?php echo e($users->total()); ?> pegawai
                        </div>
                        <div>
                            <?php echo e($users->links('pagination::bootstrap-5')); ?>

                        </div>
                    </div>
                <?php else: ?>
                    <div class="text-center py-5">
                        <?php if($search): ?>
                            <i class="fas fa-search fa-4x text-muted mb-3"></i>
                            <h5 class="text-muted">Tidak ada hasil pencarian</h5>
                            <p class="text-muted">Tidak ditemukan pegawai dengan kata kunci "<strong><?php echo e($search); ?></strong>"</p>
                            <a href="<?php echo e(route('admin.kelola-akun')); ?>" class="btn btn-secondary">
                                <i class="fas fa-arrow-left me-2"></i>Kembali ke Daftar Pegawai
                            </a>
                        <?php else: ?>
                            <i class="fas fa-users fa-4x text-muted mb-3"></i>
                            <h5 class="text-muted">Belum ada pegawai</h5>
                            <p class="text-muted">Mulai dengan menambahkan pegawai pertama.</p>
                            <a href="<?php echo e(route('admin.tambah-akun')); ?>" class="btn btn-primary">
                                <i class="fas fa-plus me-2"></i>Tambah Pegawai Pertama
                            </a>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Laragon\laragon\www\WOLA\resources\views/admin/kelola-akun.blade.php ENDPATH**/ ?>