

<?php $__env->startSection('title', 'Dashboard Admin'); ?>

<?php $__env->startSection('content'); ?>
<!-- Welcome Card -->
<div class="row mb-3">
    <div class="col-12">
        <div class="card admin-card">
            <div class="card-body text-center">
                <h2 class="mb-2">
                    <i class="fas fa-user-shield me-2"></i>Selamat Datang, Admin!
                </h2>
                <h5 class="mb-0"><?php echo e(Auth::user()->name); ?></h5>
            </div>
        </div>
    </div>
</div>

<!-- Simplified Statistics (Compact) -->
<div class="row mb-3">
    <div class="col-md-4 mb-3">
        <div class="card stats-card">
            <div class="card-body text-center py-4">
                <i class="fas fa-users fa-lg mb-2"></i>
                <div class="stats-number" style="font-size: 1.75rem;"><?php echo e($totalEmployees); ?></div>
                <p class="mb-0">Total Pegawai</p>
            </div>
        </div>
    </div>
    <div class="col-md-4 mb-3">
        <div class="card stats-card">
            <div class="card-body text-center py-4">
                <i class="fas fa-tasks fa-lg mb-2"></i>
                <div class="stats-number" style="font-size: 1.75rem;"><?php echo e($totalTasks); ?></div>
                <p class="mb-0">Total Tugas</p>
            </div>
        </div>
    </div>
    <div class="col-md-4 mb-3">
        <div class="card stats-card">
            <div class="card-body text-center py-4">
                <i class="fas fa-bell fa-lg mb-2"></i>
                <div class="stats-number" style="font-size: 1.75rem;"><?php echo e($unreadNotifications); ?></div>
                <p class="mb-0">Notifikasi Belum Dibaca</p>
            </div>
        </div>
    </div>
</div>
<!-- Recent Entries -->
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0">
                    <i class="fas fa-history me-2"></i>Entri Terbaru
                </h5>
                <a href="<?php echo e(route('admin.kelola-akun')); ?>" class="btn btn-sm btn-outline-primary">
                    Lihat Semua Pegawai
                </a>
            </div>
            <div class="card-body">
                <?php if($recentEntries->count() > 0): ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Pegawai</th>
                                    <th>Uraian Tugas</th>
                                    <th>Jumlah</th>
                                    <th>Satuan</th>
                                    <th>Total Menit</th>
                                    <th>Tanggal</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $recentEntries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($index + 1); ?></td>
                                        <td><?php echo e($entry->user->name); ?></td>
                                        <td><?php echo e($entry->task->task_description); ?></td>
                                        <td><?php echo e($entry->quantity); ?></td>
                                        <td>
                                            <?php switch($entry->time_unit):
                                                case ('daily'): ?>
                                                    <span class="badge" style="background: linear-gradient(135deg, #17a2b8, #138496);">Harian</span>
                                                    <?php break; ?>
                                                <?php case ('weekly'): ?>
                                                    <span class="badge" style="background: linear-gradient(135deg, #f1c40f, #f39c12);">Mingguan</span>
                                                    <?php break; ?>
                                                <?php case ('monthly'): ?>
                                                    <span class="badge" style="background: linear-gradient(135deg, #27ae60, #2ecc71);">Bulanan</span>
                                                    <?php break; ?>
                                                <?php case ('yearly'): ?>
                                                    <span class="badge" style="background: linear-gradient(135deg, #1e5f5f, #2d8f8f);">Tahunan</span>
                                                    <?php break; ?>
                                            <?php endswitch; ?>
                                        </td>
                                        <td><?php echo e(number_format($entry->total_minutes)); ?> menit</td>
                                        <td><?php echo e($entry->created_at->format('d/m/Y H:i')); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                <?php else: ?>
                    <div class="text-center py-4">
                        <i class="fas fa-inbox fa-3x text-muted mb-3"></i>
                        <h5 class="text-muted">Belum ada entri beban kerja</h5>
                        <p class="text-muted">Pegawai belum melakukan input beban kerja.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Laragon\laragon\www\WOLA\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>